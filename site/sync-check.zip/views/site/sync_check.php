<style type="text/css">
* {
  text-align: left;
}

td {
  min-width: 200px;
}

h2 {
  font-size: 18px;
}
</style>
<h2>Sync from block 0</h2>
<table border="1">
  <th>
    Node
  </th>
  <th>
    Height
  </th>
  <th>
    alt_blocks_count
  </th>
  <th>
    status
  </th>
  <?php foreach ($scratch as $node => $data): ?>
    <tr>
      <td>
        <?php echo $node?>
      </td>
      <td>
        <?php echo $data['height']?>
      </td>
      <td>
        <?php echo $data['alts']?>
      </td>
      <td>
        <?php echo $data['status']?>
      </td>
    </tr>
  <?php endforeach ?>
</table>

<h2>Sync from block 104948</h2>
<table border="1">
  <th>
    Node
  </th>
  <th>
    Height
  </th>
  <th>
    alt_blocks_count
  </th>
  <th>
    status
  </th>
  <?php foreach ($resume as $node => $data): ?>
    <tr>
      <td>
        <?php echo $node?>
      </td>
      <td>
        <?php echo $data['height']?>
      </td>
      <td>
        <?php echo $data['alts']?>
      </td>
      <td>
        <?php echo $data['status']?>
      </td>
    </tr>
  <?php endforeach ?>
</table>
<p>
  <script type="text/javascript">
    var currentdate = new Date();
    var localtime =  currentdate.getHours() + ":"
                + currentdate.getMinutes() + ":"
                + currentdate.getSeconds();
  </script>
  Updated at <script type="text/javascript">document.write(localtime);</script>
</p>
<script type="text/javascript">
  setTimeout(function(){
    window.location = '/'
  },10000)
</script>

<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string
     */
    public function actionIndex()
    {
      $nodes_scratch = array(
        "127.0.0.1",
      );
      $nodes_resume = array(
        "127.0.0.1",
      );

      $data_scratch = array();
      foreach ($nodes_scratch as $node)
      {
        $data_scratch[$node] = $this->getNodeHeight($node);
      }
      $data_resume = array();
      foreach ($nodes_resume as $node)
      {
        $data_resume[$node] = $this->getNodeHeight($node);
      }

      $this->layout = 'blank';
      return $this->render("sync_check", [
        "scratch" => $data_scratch,
        "resume" => $data_resume,
      ]);
      //return $this->render('index');
    }

    public function getNodeHeight($ip)
    {

      $ch = curl_init('http://' . $ip . ':20189/getheight');
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS, '');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json',
      ));

      $result = curl_exec($ch);
      if(curl_error($ch))
      {
          return curl_error($ch);
      }

      $r = json_decode($result);
      $height = $r->height;

      $ch = curl_init('http://' . $ip . ':20189/json_rpc');
      $payload = json_encode( array(
        "jsonrpc"=> "2.0",
        "id"=> "0",
         "method" => "get_info",
      ) );
      //curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));

      $result = curl_exec($ch);
      if(curl_error($ch))
      {
          return curl_error($ch);
      }
      $r = json_decode($result);
      $alt_blocks_count = $r->result->alt_blocks_count;
      $status = $r->result->status;
      return array(
        "height" => $height,
        "alts" =>$alt_blocks_count,
        "status" => $status,
      );
    }
}

<div class="center-holder">
  <div class="header">
    Header
  </div>
  <div class="grid">
    <section class="logo">
      <img src="/i/logo-large.png"/>
    </section>
    <div class="div1 shown">
      <div class="market-cap">
        <h2>
          USD 500 million
        </h2>
        <span>
          Market cap
        </span>
      </div>
    </div>
    <div class="div2 shown">
      Current Price
    </div>
    <div class="div3 shown">
      Date
    </div>
    <div class="div4 shown">
      height
    </div>
    <div class="div5 shown">
      difficulty
    </div>
    <div class="div6 shown">
      last block
    </div>
    <div class="div7 shown">
      block reward
    </div>
    <div class="div8 shown">
      circulation
    </div>
    <div class="div9 shown">
      graph
    </div>
  </div>
</div>
